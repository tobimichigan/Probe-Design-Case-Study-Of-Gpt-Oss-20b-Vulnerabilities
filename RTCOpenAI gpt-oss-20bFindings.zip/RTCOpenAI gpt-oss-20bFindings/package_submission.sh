#!/usr/bin/env bash
set -euo pipefail

# package_submission.sh
# Short packaging script to collect code, data, and figures into a submission ZIP.
# Usage: chmod +x package_submission.sh && ./package_submission.sh

ROOT_DIR="$(pwd)"
OUT_DIR="$ROOT_DIR/submission_package"
ZIP_NAME="gpt_oss20b_redteam_submission.zip"
MANIFEST="MANIFEST.txt"

echo "Creating packaging directory at: $OUT_DIR"
rm -rf "$OUT_DIR"
mkdir -p "$OUT_DIR"

# Candidate files/dirs to include (only copied if present)
items=(
  "findings_raw.json"
  "gpt_oss20b_scan_summary.csv"
  "figures"
  "scripts"
  "requirements.txt"
  "ANNOTATIONS.md"
  "README_REPRO.md"
  "prompts"
)

for item in "${items[@]}"; do
  if [ -e "$ROOT_DIR/$item" ]; then
    echo "Including: $item"
    cp -r "$ROOT_DIR/$item" "$OUT_DIR/"
  else
    echo "Skipping (not found): $item"
  fi
done

# Create manifest of files with sha256 checksums
pushd "$OUT_DIR" > /dev/null
echo "Generating $MANIFEST with SHA256 checksums..."
# find regular files only, sort for consistent manifest
find . -type f | sort > /tmp/_pack_files_list.txt
if [ -s /tmp/_pack_files_list.txt ]; then
  sha256sum $(cat /tmp/_pack_files_list.txt) > "$MANIFEST"
else
  echo "Warning: no files were found in $OUT_DIR to include in manifest."
  echo "" > "$MANIFEST"
fi
popd > /dev/null

# Create ZIP archive (in ROOT_DIR)
echo "Creating ZIP archive: $ZIP_NAME"
rm -f "$ROOT_DIR/$ZIP_NAME"
pushd "$OUT_DIR" > /dev/null
zip -r "$ROOT_DIR/$ZIP_NAME" .
popd > /dev/null

echo "Created $ROOT_DIR/$ZIP_NAME"
echo "Done."
