# GPT-OSS-20B Red Team — Reproducibility Pack (Short README)

## Purpose
This package bundles the minimal artifacts needed to reproduce the quantitative red-team analysis for GPT-OSS-20B: code, raw scan outputs, generated figures, and a packaging script to create a submission-ready ZIP archive.

## Expected contents (place in repository root)
- `findings_raw.json`            — raw per-probe JSON outputs (required)
- `gpt_oss20b_scan_summary.csv`  — derived CSV summary (required)
- `figures/`                     — generated figures (PNG + interactive HTML) (optional but recommended)
- `scripts/`                     — analysis and figure-generation scripts (required)
- `requirements.txt`             — Python dependencies (optional)
- `ANNOTATIONS.md`               — annotation rubric (optional)

## Quickstart (local)
1. Place this README and `package_submission.sh` at the root of your project (next to `findings_raw.json`).
2. (Optional) Create virtualenv and install deps:
   ```bash
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```
3. Generate figures (if you haven't already). Example commands (adjust paths as needed):
   ```bash
   python scripts/generate_fig1.py --input findings_raw.json --out figures/png/fig1_response_pattern.png
   python scripts/generate_fig2_wordcloud.py --input findings_raw.json --out figures/png/fig2_wordclouds/
   python scripts/generate_heatmap.py --input gpt_oss20b_scan_summary.csv --out figures/interactive/heatmap.html
   ```
4. Create the submission ZIP:
   ```bash
   chmod +x package_submission.sh
   ./package_submission.sh
   ```
   The script will create `gpt_oss20b_redteam_submission.zip` in the repository root.

## Notes
- The packaging script will include only files that exist. It writes a `MANIFEST.txt` with SHA256 checksums for all included files.
- If `run_scan.py` is present and you want to re-run scans, ensure you have a running GPT-OSS-20B endpoint and edit `scripts/run_scan.py` to point to it.
- The interactive figures are standalone HTML files and can be opened in a browser.

## Contact
If you need the longer README with full instructions or a LaTeX-ready paper export, ask and I will generate it.
